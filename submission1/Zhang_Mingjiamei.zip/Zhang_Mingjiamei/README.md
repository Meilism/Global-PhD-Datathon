# Global-PhD-Datathon

This is the repo for my submission to Correlation One's Global PhD Datathon.
The goal of this project is to analyze the Upworthy Research Archive and give recommendations for media companies to increase the virality of their content.

## Data
The Upworthy Research Archive

## Code
To set up the environment, run `pip install -r requirements.txt`.